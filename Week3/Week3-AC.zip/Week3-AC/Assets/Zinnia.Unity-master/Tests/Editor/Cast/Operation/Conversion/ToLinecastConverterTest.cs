﻿using Zinnia.Cast;
using Zinnia.Cast.Operation.Conversion;

namespace Test.Zinnia.Cast.Operation.Conversion
{
    using NUnit.Framework;
    using UnityEngine;

    public class ToLinecastConverterTest
    {
        private GameObject containingObject;
        private PhysicsCast caster;
        private ToLinecastConverter subject;
        private GameObject validSurface;

        [SetUp]
        public void SetUp()
        {
#if UNITY_2022_2_OR_NEWER
            Physics.simulationMode = SimulationMode.Script;
#else
            Physics.autoSimulation = false;
#endif
            containingObject = new GameObject("ToLinecastConverterTest");
            caster = containingObject.AddComponent<PhysicsCast>();
            subject = containingObject.AddComponent<ToLinecastConverter>();
            validSurface = GameObject.CreatePrimitive(PrimitiveType.Cube);
            validSurface.transform.position = (Vector3.forward * 2f) + (Vector3.up * 0.55f);
            Physics.Simulate(Time.fixedDeltaTime);
        }

        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(containingObject);
            Object.DestroyImmediate(validSurface);
#if UNITY_2022_2_OR_NEWER
            Physics.simulationMode = SimulationMode.FixedUpdate;
#else
            Physics.autoSimulation = true;
#endif
        }

        [Test]
        public void ConvertFromBoxCast()
        {
            bool result = caster.CustomBoxCast(Vector3.zero, Vector3.one * 0.1f, Vector3.forward, out RaycastHit hitData, Quaternion.identity, 10f);
            Assert.IsTrue(result);
            Assert.AreEqual(validSurface, hitData.transform.gameObject);

            caster.ConvertTo = subject;
            result = caster.CustomBoxCast(Vector3.zero, Vector3.one * 0.1f, Vector3.forward, out RaycastHit missData, Quaternion.identity, 10f);
            Assert.IsFalse(result);
            Assert.IsNull(missData.transform);
        }

        [Test]
        public void ConvertFromCapsuleCast()
        {
            bool result = caster.CustomCapsuleCast(Vector3.up * 0.1f, Vector3.up * -0.1f, 0.1f, Vector3.forward, out RaycastHit hitData, 10f);
            Assert.IsTrue(result);
            Assert.AreEqual(validSurface, hitData.transform.gameObject);

            caster.ConvertTo = subject;
            result = caster.CustomCapsuleCast(Vector3.up * 0.1f, Vector3.up * -0.1f, 0.1f, Vector3.forward, out RaycastHit missData, 10f);
            Assert.IsFalse(result);
            Assert.IsNull(missData.transform);
        }

        [Test]
        public void ConvertFromLinecast()
        {
            caster.ConvertTo = subject;
            bool result = caster.CustomLinecast(Vector3.zero, Vector3.forward * 10f, out RaycastHit missData);
            Assert.IsFalse(result);
            Assert.IsNull(missData.transform);
        }

        [Test]
        public void ConvertFromRaycast()
        {
            caster.ConvertTo = subject;
            bool result = caster.CustomRaycast(new Ray(Vector3.zero, Vector3.forward), out RaycastHit missData, 10f);
            Assert.IsFalse(result);
            Assert.IsNull(missData.transform);
        }

        [Test]
        public void ConvertFromSphereCast()
        {
            bool result = caster.CustomSphereCast(Vector3.zero, 0.1f, Vector3.forward, out RaycastHit hitData, 10f);
            Assert.IsTrue(result);
            Assert.AreEqual(validSurface, hitData.transform.gameObject);

            caster.ConvertTo = subject;
            result = caster.CustomSphereCast(Vector3.zero, 0.1f, Vector3.forward, out RaycastHit missData, 10f);
            Assert.IsFalse(result);
            Assert.IsNull(missData.transform);
        }
    }
}