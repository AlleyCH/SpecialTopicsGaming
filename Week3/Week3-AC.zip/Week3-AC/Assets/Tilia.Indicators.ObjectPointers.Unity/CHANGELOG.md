# Changelog

### [2.2.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.9...v2.2.10) (2023-07-10)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([27464ba](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/27464bac8f6301dfd4f716a940addcdf87db18bc))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.18 to 2.0.19. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.18...v2.0.19)

### [2.2.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.8...v2.2.9) (2023-07-10)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.14.0 to 2.15.0 ([eba2627](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/eba2627288ac5e6d0d2373df96cfed567f2b5f32))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.14.0 to 2.15.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.14.0...v2.15.0)

### [2.2.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.7...v2.2.8) (2023-07-08)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([8672ef7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/8672ef79372fdfe34d55dc34b36782253f7b201d))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.17 to 2.0.18. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.17...v2.0.18)

### [2.2.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.6...v2.2.7) (2023-07-08)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.13.0 to 2.14.0 ([fb5cb4e](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fb5cb4e508ac01f36dab07a6208ecf3c4a15d1c1))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.13.0 to 2.14.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.13.0...v2.14.0)

### [2.2.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.5...v2.2.6) (2023-07-05)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([01e0f9a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/01e0f9af682fa872b02807a62f4f938407102a2b))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.16 to 2.0.17. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.16...v2.0.17)

### [2.2.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.4...v2.2.5) (2023-07-05)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.12.1 to 2.13.0 ([72d1ee2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/72d1ee20d6c25f4fd2f7d4a385de04e658856f86))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.12.1 to 2.13.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.12.1...v2.13.0)

### [2.2.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.3...v2.2.4) (2023-06-14)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([6073688](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/60736888338c8d3c8bee963f51b1427f48698519))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.3.1 to 1.4.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.3.1...v1.4.0)

### [2.2.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.2...v2.2.3) (2023-05-06)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([27cac1d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/27cac1d0f5272366039a6d9229c4fa302db56bcb))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.15 to 2.0.16. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.15...v2.0.16)

### [2.2.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.1...v2.2.2) (2023-05-06)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.12.0 to 2.12.1 ([fe47d58](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fe47d5832319544e9395c06e9b804b84ba137fd6))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.12.0 to 2.12.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.12.0...v2.12.1)

### [2.2.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.2.0...v2.2.1) (2023-05-02)

#### Bug Fixes

* **Configuration:** re-apply select on deactivate action ([9c26e2a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/9c26e2a8ca4bb07288750567ead8545953c917d9))
  > The change to the run when enabled logic broke the select on deactive action as the code to set it up was never being run.

## [2.2.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.29...v2.2.0) (2023-05-02)

#### Features

* **Facade:** expose new point cast restriction options ([2173f24](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/2173f2430d8d17f633b6754443b62abcb60d1024))
  > The PointsCast now provides a CursorLockThreshold and TransitionDuration option which is now exposed on the PointerFacade to allow these options to be set.

#### Bug Fixes

* **Configuration:** ensure setup is run correctly on enable ([f514b3d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f514b3daf264b8708904638147823a1df632d200))
  > The RunWhenActiveAndEnabled logic could cause an issue where it was hitting race conditions and not setting up correctly. This is now handled by calling a single method rather than queuing methods.
  > 
  > The configuration now also disables the points caster instead of the moment processor that controls the points caster, so the relevant setup is run correctly whenever the pointer is activated.
  > 
  > The Facade and Configuration reference fields are also now public to allow manual creation if required.

### [2.1.29](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.28...v2.1.29) (2023-05-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([674a719](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/674a7195238fbd4b65d26e1bc04203ee3326ca08))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.14 to 2.0.15. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.14...v2.0.15)

### [2.1.28](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.27...v2.1.28) (2023-05-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.11.0 to 2.12.0 ([748d787](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/748d78751f21bb3a5b8e0e8cf11ec78f5975d902))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.11.0 to 2.12.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.11.0...v2.12.0)

### [2.1.27](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.26...v2.1.27) (2023-04-16)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([d65b37c](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/d65b37c4fd45c6e5fe95ca510f55acdf084b5d13))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.13 to 2.0.14. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.13...v2.0.14)

### [2.1.26](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.25...v2.1.26) (2023-04-16)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.10.0 to 2.11.0 ([f3ae299](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f3ae299a08702c984e6bf64437d793200e57eb53))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.10.0 to 2.11.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.10.0...v2.11.0)

### [2.1.25](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.24...v2.1.25) (2023-04-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([620bbd8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/620bbd81e930d4090dc33c0eea1bfe7a38d85d4e))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.12 to 2.0.13. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.12...v2.0.13)

### [2.1.24](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.23...v2.1.24) (2023-04-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.9.0 to 2.10.0 ([d2961a6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/d2961a64ca332632ce665c435724936402129726))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.9.0 to 2.10.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.9.0...v2.10.0)

### [2.1.23](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.22...v2.1.23) (2023-03-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([eca2d72](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/eca2d721869ef8b472ba10d82b52d16d3e454671))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.11 to 2.0.12. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.11...v2.0.12)

### [2.1.22](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.21...v2.1.22) (2023-03-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.8.0 to 2.9.0 ([6d4c487](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6d4c4879946a46b6b2d6d0743d744fe6ad9ebba5))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.8.0 to 2.9.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.8.0...v2.9.0)

### [2.1.21](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.20...v2.1.21) (2023-03-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([eb42146](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/eb42146a838452d5c38ec462e386c98f486508d1))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.10 to 2.0.11. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.10...v2.0.11)

### [2.1.20](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.19...v2.1.20) (2023-03-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.7.2 to 2.8.0 ([818211c](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/818211cbd63ee1f39edc7b5a9cc04c66437ff01b))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.7.2 to 2.8.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.7.2...v2.8.0)

### [2.1.19](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.18...v2.1.19) (2023-03-16)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([6a0c8e2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6a0c8e2c41b7b96a8124f8b7de35e31bff5768b2))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.9 to 2.0.10. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.9...v2.0.10)

### [2.1.18](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.17...v2.1.18) (2023-03-16)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.7.1 to 2.7.2 ([2175275](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/21752757a6a20bea276ae4b0529f109bb5c0823f))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.7.1 to 2.7.2. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.7.1...v2.7.2)

### [2.1.17](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.16...v2.1.17) (2023-03-13)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([badbaa4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/badbaa4c559550e1776eef9b486618324d0f9cd5))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.8 to 2.0.9. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.8...v2.0.9)

### [2.1.16](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.15...v2.1.16) (2023-03-13)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.7.0 to 2.7.1 ([c1aec5f](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c1aec5f326f88812cf8a8545e286a297f4c32858))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.7.0 to 2.7.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.7.0...v2.7.1)

### [2.1.15](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.14...v2.1.15) (2023-03-11)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([478978e](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/478978ec5624aeeb3b68b5d4654f0c1323e07ee5))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.7 to 2.0.8. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.7...v2.0.8)

### [2.1.14](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.13...v2.1.14) (2023-03-11)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.6.0 to 2.7.0 ([0b1a639](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/0b1a6399b830e1320f39ff0e238297492119c127))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.6.0 to 2.7.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.6.0...v2.7.0)

### [2.1.13](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.12...v2.1.13) (2023-02-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([09024c5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/09024c547521231bd5849594c33542465c5d9c38))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.6 to 2.0.7. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.6...v2.0.7)

### [2.1.12](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.11...v2.1.12) (2023-02-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.5.0 to 2.6.0 ([1459980](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/1459980054efa88a8db1daab3b68e82c225a967e))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.5.0 to 2.6.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.5.0...v2.6.0)

### [2.1.11](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.10...v2.1.11) (2023-02-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([edbc40d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/edbc40d347c9efd87acfe92995257ca7b7483544))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.5 to 2.0.6. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.5...v2.0.6)

### [2.1.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.9...v2.1.10) (2023-02-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.4.0 to 2.5.0 ([97d37d6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/97d37d6fe2f046ef469f945080e29e067965548a))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.4.0 to 2.5.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.4.0...v2.5.0)

### [2.1.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.8...v2.1.9) (2023-02-08)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([bc921a4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/bc921a4ee2b9c066a479c7160ea021f4c5d73782))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.4 to 2.0.5. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.4...v2.0.5)

### [2.1.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.7...v2.1.8) (2023-02-08)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.3.0 to 2.4.0 ([c4e8562](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c4e8562e5768597c4888924015eb7e5178732ffc))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.3.0 to 2.4.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.3.0...v2.4.0)

### [2.1.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.6...v2.1.7) (2022-06-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([4698e64](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/4698e64b04aa27ce547e715504356f11e3a26139))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.3.0 to 1.3.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.3.0...v1.3.1)

### [2.1.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.5...v2.1.6) (2022-06-16)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([6c21e8f](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6c21e8f0f3f42ff9e48bfa30d7fc1e7d4cf215db))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.3 to 2.0.4. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.3...v2.0.4)

### [2.1.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.4...v2.1.5) (2022-06-16)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.2.0 to 2.3.0 ([8ba7029](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/8ba70297c3e06e181ad7a6a811bf78adbebc697b))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.2.0 to 2.3.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.2.0...v2.3.0)

### [2.1.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.3...v2.1.4) (2022-05-20)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([d33d1d8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/d33d1d8285ec1002fe676924536f7fd441664220))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.2 to 2.0.3. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.2...v2.0.3)

### [2.1.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.2...v2.1.3) (2022-05-20)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.1.0 to 2.2.0 ([6bf8c2b](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6bf8c2bfffb1fedf5dacaf4482419faca8e7d4d0))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.1.0 to 2.2.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.1.0...v2.2.0)

### [2.1.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.1...v2.1.2) (2022-05-09)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([b3eb990](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/b3eb9906eea1ecfa0175ed220cd4c00e8a38d08f))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.1 to 2.0.2. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.1...v2.0.2)

### [2.1.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.1.0...v2.1.1) (2022-05-09)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 2.0.0 to 2.1.0 ([8fbdcc6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/8fbdcc6818a7dd438d74a54857498f31ab83ff1e))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 2.0.0 to 2.1.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v2.0.0...v2.1.0)

## [2.1.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.0.3...v2.1.0) (2022-05-02)

#### Features

* **Facade:** add hover validity setting ([7235344](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/72353446baf5860468e3cd12fe68fd960ba3d507))
  > The new Hover Validity restriction setting can be used to determine which objects can be considered valid for hover actions such as entered, exitit and hover changed. The Rule will simply block the Facade events from emitting and won't change any internal states.

### [2.0.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.0.2...v2.0.3) (2022-04-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([395a7e2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/395a7e23be055d6a5f6c7ec459a601f9c3aa0bc1))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 2.0.0 to 2.0.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v2.0.0...v2.0.1)

### [2.0.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.0.1...v2.0.2) (2022-04-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.47.1 to 2.0.0 ([76d86e4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/76d86e48b511f8ee111f898736888a43d728bd46))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.47.1 to 2.0.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.47.1...v2.0.0)

### [2.0.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v2.0.0...v2.0.1) (2022-04-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([213fa63](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/213fa63f20a3b9a6b6430d55767cf45c95bac7ec))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.3.2 to 2.0.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.3.2...v2.0.0)

## [2.0.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.6...v2.0.0) (2022-04-28)

#### :warning: BREAKING CHANGES :warning:

* **Malimbe:** This removes the last remaining elements of Malimbe and whilst it does not cause any breaking changes within this package, it removes Malimbe as a dependency which other projects that rely on this package may piggy back off this Malimbe dependency so it will break any project like that.

All of the previous functionality from Malimbe has been replicated in standard code without the need for it to be weaved by the Malimbe helper tags. ([b31fac4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/b31fac49e962f0aeab9f90824532e75433ad6cc6))

#### Features

* **Malimbe:** remove malimbe dependency ([b31fac4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/b31fac49e962f0aeab9f90824532e75433ad6cc6))

### [1.8.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.5...v1.8.6) (2022-03-15)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([398c2ff](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/398c2ff407dda187ed365206bbafcc9a4f799e55))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.3.1 to 1.3.2. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.3.1...v1.3.2)

### [1.8.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.4...v1.8.5) (2022-03-15)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.47.0 to 1.47.1 ([f004a86](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f004a86b865dc3d653c74c037778af3f930fa0af))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.47.0 to 1.47.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.47.0...v1.47.1)

### [1.8.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.3...v1.8.4) (2022-03-15)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([a177a67](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/a177a674b18b137d6a7e5791b44bf859d2883da0))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.3.0 to 1.3.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.3.0...v1.3.1)

### [1.8.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.2...v1.8.3) (2022-03-15)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.46.0 to 1.47.0 ([fb27637](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fb27637d2d7b913cfef3f72d985e1885479482a0))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.46.0 to 1.47.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.46.0...v1.47.0)

### [1.8.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.1...v1.8.2) (2022-03-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([7f9f7d4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7f9f7d411fd1dc73d33d73d7a872f5013a503365))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.15 to 1.3.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.15...v1.3.0)

### [1.8.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.8.0...v1.8.1) (2022-03-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([c7204b6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c7204b6e179deb9cc37641ee95ef627dfa681e88))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.2.0 to 1.3.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.2.0...v1.3.0)

## [1.8.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.32...v1.8.0) (2022-03-02)

#### Features

* **package.json:** add information urls to package ([d9e2258](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/d9e2258d73d86ac5231ae2bb5df6bdd11d0bb0ac))
  > The changelog, documentation and license url has been added to the package.json as these are used within the Unity package manager.

### [1.7.32](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.31...v1.7.32) (2022-02-14)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([300f736](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/300f736d6db9348d82e52de43af324af6ee7ae20))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.14 to 1.2.15. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.14...v1.2.15)

### [1.7.31](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.30...v1.7.31) (2022-02-14)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.45.0 to 1.46.0 ([48a52ae](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/48a52aecc56a3e6eea44e04ed2518383ccf64429))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.45.0 to 1.46.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.45.0...v1.46.0)

### [1.7.30](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.29...v1.7.30) (2022-02-05)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([59ef6c9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/59ef6c9323aac31669763dbb1827c26a370bf5f8))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.13 to 1.2.14. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.13...v1.2.14)

### [1.7.29](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.28...v1.7.29) (2022-02-05)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.44.0 to 1.45.0 ([24e7fb9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/24e7fb9186162effc5a0dde49309c7a7a87c6ac3))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.44.0 to 1.45.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.44.0...v1.45.0)

### [1.7.28](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.27...v1.7.28) (2022-01-17)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([64b5db9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/64b5db9ebb89f724be3b4751255fd8057ed32ffb))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.12 to 1.2.13. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.12...v1.2.13)

### [1.7.27](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.26...v1.7.27) (2022-01-17)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.43.0 to 1.44.0 ([0afefb8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/0afefb8d426aef4617ae17b0cbaebe7d76e8aac0))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.43.0 to 1.44.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.43.0...v1.44.0)

### [1.7.26](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.25...v1.7.26) (2022-01-13)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([2cc3a39](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/2cc3a39ddae62aa6cb6528408b8147993d7f286d))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.11 to 1.2.12. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.11...v1.2.12)

### [1.7.25](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.24...v1.7.25) (2022-01-13)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.42.0 to 1.43.0 ([04cee64](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/04cee64a53eb375793dce8fcf850711b66152c95))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.42.0 to 1.43.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.42.0...v1.43.0)

### [1.7.24](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.23...v1.7.24) (2022-01-13)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([458adc1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/458adc110260d2b1c784db5e04cc0552ef7ab78c))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.10 to 1.2.11. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.10...v1.2.11)

### [1.7.23](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.22...v1.7.23) (2022-01-13)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.41.0 to 1.42.0 ([ba85530](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/ba8553011f138e998626f82d7e6039940b1fd283))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.41.0 to 1.42.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.41.0...v1.42.0)

### [1.7.22](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.21...v1.7.22) (2022-01-12)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([fc249f5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fc249f51fabddf8e4fcfed21bd5ef669726807c1))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.9 to 1.2.10. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.9...v1.2.10)

### [1.7.21](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.20...v1.7.21) (2022-01-12)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.40.0 to 1.41.0 ([33d06e1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/33d06e1ebc90b53c2d7129a3dbafc2f4a05dc85a))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.40.0 to 1.41.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.40.0...v1.41.0)

### [1.7.20](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.19...v1.7.20) (2022-01-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([fbeaa0a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fbeaa0a25d04252747f1aee6480df3f88e93f9dc))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.8 to 1.2.9. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.8...v1.2.9)

### [1.7.19](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.18...v1.7.19) (2022-01-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.39.0 to 1.40.0 ([f07445e](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f07445e502c47d2294a491f71ce9cd6be33cca1f))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.39.0 to 1.40.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.39.0...v1.40.0)

### [1.7.18](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.17...v1.7.18) (2021-12-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([7a32d0d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7a32d0db08853a23f87733fddd468d36e1223386))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.7 to 1.2.8. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.7...v1.2.8)

### [1.7.17](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.16...v1.7.17) (2021-12-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.38.1 to 1.39.0 ([fdad1dc](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fdad1dc5ecb0fdd919c5ec908d0adf88e6b5a6bc))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.38.1 to 1.39.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.38.1...v1.39.0)

### [1.7.16](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.15...v1.7.16) (2021-07-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([77a859d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/77a859d46a1eebc19e96eed26b8a1b5a7c6f3e53))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.6 to 1.2.7. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.6...v1.2.7)

### [1.7.15](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.14...v1.7.15) (2021-07-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.38.0 to 1.38.1 ([6dbe278](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6dbe278f8ba16571688f3b07eae12a4e3c5851f4))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.38.0 to 1.38.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.38.0...v1.38.1)

### [1.7.14](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.13...v1.7.14) (2021-07-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([5b232fe](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/5b232fe19855fdaede11e038f44420bd81708b76))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.5 to 1.2.6. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.5...v1.2.6)

### [1.7.13](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.12...v1.7.13) (2021-07-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.37.0 to 1.38.0 ([43ea738](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/43ea7380895b9433ff33634fa60d0914de94c93e))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.37.0 to 1.38.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.37.0...v1.38.0)

### [1.7.12](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.11...v1.7.12) (2021-06-24)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([235c7cc](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/235c7cc14ce876b4687ea240eee28ed2bfd8f208))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.4 to 1.2.5. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.4...v1.2.5)

### [1.7.11](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.10...v1.7.11) (2021-06-24)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.36.2 to 1.37.0 ([f174b9b](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f174b9b596106fa7276ba5ee3e436edc544a0826))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.36.2 to 1.37.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.36.2...v1.37.0)

### [1.7.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.9...v1.7.10) (2021-06-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([18b2cb8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/18b2cb8289c1d60cbed0a79cbc345182cb7c16f8))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.3 to 1.2.4. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.3...v1.2.4)

### [1.7.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.8...v1.7.9) (2021-06-19)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.36.1 to 1.36.2 ([54092fe](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/54092fe9efc11e907e58c235ea0b93bded0cadcb))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.36.1 to 1.36.2. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.36.1...v1.36.2)

### [1.7.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.7...v1.7.8) (2021-06-10)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([1c66354](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/1c6635436c7285a0144ba5e83b094b55d3f683b0))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.2 to 1.2.3. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.2...v1.2.3)

### [1.7.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.6...v1.7.7) (2021-06-10)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.36.0 to 1.36.1 ([72b0f3f](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/72b0f3fe108f160dfcf303c13ba1637cb27c2b5e))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.36.0 to 1.36.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.36.0...v1.36.1)

### [1.7.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.5...v1.7.6) (2021-06-10)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([cc2230e](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/cc2230eedcc4a6aaa2b5d5b931f947c7bd956ec3))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.1.0 to 1.2.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.1.0...v1.2.0)
* **README.md:** update title logo to related-media repo ([c7c7248](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c7c724891b0388c7c20bcbd0c86739afa6ca1a7b))
  > The title logo is now located on the related-media repo.

### [1.7.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.4...v1.7.5) (2021-05-09)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([c3dcc45](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c3dcc4523cb94c424cd9dc6b3c48324592f314bc))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.1 to 1.2.2. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.1...v1.2.2)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.7.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.3...v1.7.4) (2021-05-09)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.35.0 to 1.36.0 ([2d560d1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/2d560d119fd3377636acb95d7cccd8c0be82ee0d))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.35.0 to 1.36.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.35.0...v1.36.0)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.7.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.2...v1.7.3) (2021-05-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([862948f](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/862948fe447cd61088c10471be23b6e36f2c3b79))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.2.0 to 1.2.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.2.0...v1.2.1)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.7.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.1...v1.7.2) (2021-05-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.34.1 to 1.35.0 ([b5adedd](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/b5adedd9069d255b0fc45459edd76ac6f24e5a64))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.34.1 to 1.35.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.34.1...v1.35.0)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.7.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.7.0...v1.7.1) (2021-04-07)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([c7e0fa6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c7e0fa6156829257e5e783bd53c1413563cfb914))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.17 to 1.2.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.17...v1.2.0)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

## [1.7.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.13...v1.7.0) (2021-04-07)

#### Features

* **Utility:** add prefab creator ([a0b3f98](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/a0b3f98d40b6a312fb6a03f47c1d5480aaadd17c))
  > The latest version of Zinnia has the basis of a prefab creator that can be used to enable easy adding of prefabs to a scene without needing to drag and drop from directories. Instead a new menu item is added for quickly adding prefabs. The guide has been updated to accommodate this and the FodyWeavers.xml is now located in the root to serve both the Runtime and Editor scripts.

#### Bug Fixes

* **package.json:** add missing reference to Editor directory ([3bb2346](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/3bb23467ba62553c50d3c6709e0464c02e81f22b))
  > The build will fail without referencing this new Editor directory so it has now been added to the package.

### [1.6.13](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.12...v1.6.13) (2021-03-29)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([6f9ae58](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6f9ae58e66024f41ae44ec620c0ac54b2716f8f1))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.16 to 1.1.17. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.16...v1.1.17)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.12](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.11...v1.6.12) (2021-03-29)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.31.1 to 1.33.0 ([c47508b](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c47508b97818ff06b7595f52928f11769f84b568))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.31.1 to 1.33.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.31.1...v1.33.0)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.11](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.10...v1.6.11) (2021-03-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([4daa586](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/4daa58675886b23b7f42415db67d57f475e8bc8e))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.15 to 1.1.16. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.15...v1.1.16)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.9...v1.6.10) (2021-03-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.31.0 to 1.31.1 ([da3c475](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/da3c475db8db2145ca2ee7b4fe565ccede597767))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.31.0 to 1.31.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.31.0...v1.31.1)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.8...v1.6.9) (2021-02-27)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([15e2d8b](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/15e2d8b2b05e0f9a5c3123ab51aec6642cf7b41a))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.14 to 1.1.15. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.14...v1.1.15)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.7...v1.6.8) (2021-02-27)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.30.0 to 1.31.0 ([437df47](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/437df47d971ff7a6f7a522e97726a5e5dd5d85f7))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.30.0 to 1.31.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.30.0...v1.31.0)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.6...v1.6.7) (2021-02-04)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([dac96e9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/dac96e981a4b4d62caa5276bc8a96df4fddcfabb))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.13 to 1.1.14. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.13...v1.1.14)
  > 
  > Signed-off-by: dependabot[bot] <support@github.com>

### [1.6.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.5...v1.6.6) (2021-02-04)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.29.0 to 1.30.0 ([7285307](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/72853072586fc080e082bb9064209b56a0a8412a))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.29.0 to 1.30.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.29.0...v1.30.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.6.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.4...v1.6.5) (2021-01-07)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([d68d7f8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/d68d7f8740d077756120b6d311ed4893721ab2ff))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.12 to 1.1.13. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.12...v1.1.13)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.6.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.3...v1.6.4) (2021-01-07)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.28.1 to 1.29.0 ([68c8cb2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/68c8cb29c3d1b728f2f627a79dfe66bacb430989))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.28.1 to 1.29.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.28.1...v1.29.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.6.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.2...v1.6.3) (2020-12-22)

#### Bug Fixes

* **HowToGuides:** provide correct worded link to package ([7257e2a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7257e2a2cb013ee9aa5cb3ebed355a3901049a2c))
  > The link to the ObjectPointers package had a `Tilia` twice in the path whereas it only needs to have it in there once.

### [1.6.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.1...v1.6.2) (2020-12-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([f3b86d8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f3b86d80f7767239e3b6a3e6ac1c513841049396))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.11 to 1.1.12. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.11...v1.1.12)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.6.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.6.0...v1.6.1) (2020-12-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.28.0 to 1.28.1 ([d6c4077](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/d6c4077d1eabccbbcdcbb6852a9f409bd6cc0c4b))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.28.0 to 1.28.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.28.0...v1.28.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

## [1.6.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.11...v1.6.0) (2020-12-17)

#### Features

* **HowToGuides:** add guide for setting invalid target for pointer ([7bef51b](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7bef51b67576c02bbcb4cd2f82c3f0e449deedf9))
  > The new Setting Invalid Targets guide shows how to use a rule to determine which GameObjects are invalid (or valid) targets for the pointer.
* **HowToGuides:** add guide of how to limit pointer to navmesh ([de1043e](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/de1043e3d71baf051fcf4fdaaa9919ad6e5a5a8c))
  > The guide shows how to limit a pointer to the bounds of a Unity NavMesh by using the Zinnia NavMeshRule.
* **HowToGuides:** add guide to show how to ignore colliders ([0e639b2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/0e639b297d60d76fc79bd2e3e1b88b0860c6063b))
  > The new Ignoring Colliders guide shows how to use a custom PhysicsCast component to get the pointer to ignore certain colliders.

### [1.5.11](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.10...v1.5.11) (2020-12-17)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([dc64acd](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/dc64acd9769559d6feb6f56b6963bd98b3d47bbc))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.10 to 1.1.11. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.10...v1.1.11)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.9...v1.5.10) (2020-12-17)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.27.0 to 1.28.0 ([fe1a6d5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fe1a6d5a89ef642f55e71a9a30abd7c657f63dc7))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.27.0 to 1.28.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.27.0...v1.28.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.8...v1.5.9) (2020-12-12)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([1617f3d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/1617f3d35ac372497c63b3ffa2dc6fb805fa1de5))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.9 to 1.1.10. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.9...v1.1.10)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.7...v1.5.8) (2020-12-12)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.25.1 to 1.27.0 ([6984ad5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/6984ad527a79289ca9247f59c41f0f103bc2adf0))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.25.1 to 1.27.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.25.1...v1.27.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.6...v1.5.7) (2020-12-11)

#### Bug Fixes

* **HowToGuides:** apply document styling guidelines ([31e4e8e](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/31e4e8ebf536b40829c75e147a47c985756cb676))
  > The document style guidelines have been updated and now have been applied to the guides in this repo.

### [1.5.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.5...v1.5.6) (2020-11-01)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([e4c16b1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/e4c16b1561c5d3fb8ea5de84a3e6e44713104203))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.8 to 1.1.9. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.8...v1.1.9)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.4...v1.5.5) (2020-11-01)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.25.0 to 1.25.1 ([fe5a928](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fe5a9283e5b560d8a30b4ad52199dca641a861dc))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.25.0 to 1.25.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.25.0...v1.25.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.3...v1.5.4) (2020-10-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([5851195](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/5851195415e5c162dfaff02c74de7b2887b7a45e))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.7 to 1.1.8. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.7...v1.1.8)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.2...v1.5.3) (2020-10-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.24.0 to 1.25.0 ([fb8a123](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/fb8a1238b1b03cad288bc483996ecaabff232cab))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.24.0 to 1.25.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.24.0...v1.25.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.1...v1.5.2) (2020-08-29)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([04ad098](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/04ad098040259ea66b0f172442e1948e50ed62bd))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.6 to 1.1.7. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.6...v1.1.7)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.5.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.5.0...v1.5.1) (2020-08-29)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.23.0 to 1.24.0 ([0164e58](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/0164e581ea5657e1092bce93272aaa21c8a2c1ea))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.23.0 to 1.24.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.23.0...v1.24.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

## [1.5.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.8...v1.5.0) (2020-08-15)

#### Features

* **Facade:** add ability to restrict pointer by target point ([43ad919](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/43ad9192299c3000268710dd1d83e2779dc3f539))
  > The Zinnia PointsCast now allows to restrict the target point of a cast to allow or deny certain points of space from being valid.
  > 
  > This is now used with the PointerFacade to allow a pointer to determine if the point in which the cursor is colliding with is valid based on a Rule.
  > 
  > It can be used in conjunction with the NavMeshRule to determine if the pointer is within the bounds of a NavMesh to consider it a valid target to select.

### [1.4.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.7...v1.4.8) (2020-08-15)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([7ac1e00](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7ac1e003b2d9224505902140a9409d3609565698))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.5 to 1.1.6. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.5...v1.1.6)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.4.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.6...v1.4.7) (2020-08-15)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.22.0 to 1.23.0 ([a3e0853](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/a3e0853c454da281fcf2a3f705036a9328cc1b8c))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.22.0 to 1.23.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.22.0...v1.23.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.4.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.5...v1.4.6) (2020-08-14)

#### Miscellaneous Chores

* **deps:** bump package dependencies ([cd06145](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/cd06145b1f7555d4c3e17893361d09bf9654c7a9))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.21.0 to 1.22.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](ExtendRealityLtd/Zinnia.Unity@v1.21.0...v1.22.0)
  > 
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.4 to 1.1.5. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity@v1.1.4...v1.1.5)

### [1.4.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.4...v1.4.5) (2020-07-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([4f0f894](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/4f0f894863de10947313f098c59146d1fb60026d))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.3 to 1.1.4. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.3...v1.1.4)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.4.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.3...v1.4.4) (2020-07-28)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.20.0 to 1.21.0 ([b18464a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/b18464a73c0ce309452ce8ffc7a1785fefbe6413))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.20.0 to 1.21.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.20.0...v1.21.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.4.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.2...v1.4.3) (2020-07-11)

#### Bug Fixes

* **Facade:** use extension method to set enum value ([f68fcfb](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f68fcfb051f55312d56467a94b4798fe0a0b26d7))
  > The SetSelectionMethod method now uses the Zinnia EnumExtensions helper method to set the value of the enum by the index instead of repeating the same logic.

### [1.4.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.1...v1.4.2) (2020-07-11)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([4ce4c06](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/4ce4c060e1a5b72d3df14d442c6eaaf35574dbe5))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.2 to 1.1.3. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.2...v1.1.3)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.4.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.4.0...v1.4.1) (2020-07-11)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.19.0 to 1.20.0 ([e53d25d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/e53d25d66ebc43d7b8af6366e2dbedab3566a208))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.19.0 to 1.20.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.19.0...v1.20.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

## [1.4.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.3.1...v1.4.0) (2020-07-07)

#### Features

* **PointerFacade:** add way to change SelectionMethod by a UnityEvent ([38f3409](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/38f3409cf196b5296193df98c9d758f612a53ffe))
  > The SelectionType property can now be changed via a UnityEvent by calling the SetSelectionMethod method and passing in the int to represent the Enum value to change to.

### [1.3.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.3.0...v1.3.1) (2020-07-04)

#### Bug Fixes

* **Documentation:** apply style guidelines ([c11a1e9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c11a1e98f6e9b69f611738b448b07ad319d5a487))
  > The guide has had the style guidelines applied to it to make it more consistent.

## [1.3.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.13...v1.3.0) (2020-07-03)

#### Features

* **API:** add auto-generated API documentation ([25863bf](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/25863bfca0ec4417e07d3e713f0a191fd261ae64))
  > The API documentation is auto generated with docfx and converted to markdown via turndown in a custom nodejs script.

#### Bug Fixes

* **package.json:** add docfx.json file ([cda9c7d](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/cda9c7d938bd1773dfb2e4b48712b700418b6ea1))
  > The docfx.json file was missing from the package.json causing the build process to fail. It has now been added.

### [1.2.13](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.12...v1.2.13) (2020-06-21)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([ea37fe4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/ea37fe4d6c6b5fcb25fe1d431829c60f95df76fd))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.1 to 1.1.2. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.1...v1.1.2)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.12](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.11...v1.2.12) (2020-06-08)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([ce69def](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/ce69def372d42c0ed20af4c19775fe4763d8d4f9))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.1.0 to 1.1.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.1.0...v1.1.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.11](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.10...v1.2.11) (2020-06-08)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.18.0 to 1.19.0 ([0dda446](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/0dda446863179d90d80bae7bc48a5f0f73bcba3c))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.18.0 to 1.19.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.18.0...v1.19.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.9...v1.2.10) (2020-06-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([a566efc](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/a566efc205d4e3826b675d9955026eb0f005f91b))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.13 to 1.1.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.13...v1.1.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.8...v1.2.9) (2020-05-31)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([f67d4ef](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f67d4ef62aa2f29aad23e75e64ae2ba4e387c214))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.12 to 1.0.13. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.12...v1.0.13)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.7...v1.2.8) (2020-05-31)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.17.1 to 1.18.0 ([47532a1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/47532a16ed5fdf16e357a82f444ddbdf0164775b))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.17.1 to 1.18.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.17.1...v1.18.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.6...v1.2.7) (2020-05-24)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([71480c8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/71480c89315af9f6d216abcee954e9bb9698d4d1))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.0.2 to 1.1.0. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.0.2...v1.1.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.5...v1.2.6) (2020-05-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([c2ed654](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/c2ed6546ff59597ed331b5e96d778a2422e255b4))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.11 to 1.0.12. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.11...v1.0.12)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.4...v1.2.5) (2020-05-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.17.0 to 1.17.1 ([f6b26af](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f6b26af38d9d5e23657360951764d5e5a1c4005d))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.17.0 to 1.17.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.17.0...v1.17.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.3...v1.2.4) (2020-05-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([ebec973](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/ebec973826511b10b465e12f3bcd3eec241cc928))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.10 to 1.0.11. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.10...v1.0.11)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.2...v1.2.3) (2020-05-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.16.0 to 1.17.0 ([7c36b34](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7c36b34bade06b8ca30937beea8a98ae71b9457d))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.16.0 to 1.17.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.16.0...v1.17.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.2.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.1...v1.2.2) (2020-05-16)

#### Bug Fixes

* **Operation:** prevent null exception if Source not set ([02d5d36](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/02d5d367c7f151e481f9e4f246da40501288b148))
  > The Source property can be null and the Extract method can be called which causes a null exception. This fix just checks to see if Source is not null before attempting to extract.

### [1.2.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.2.0...v1.2.1) (2020-04-21)

#### Bug Fixes

* **Prefabs:** send top level GameObject as event source ([0393bd2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/0393bd207c244ceccbee9f7e512e95f7c9966435))
  > Zinnia 1.16.0 brings a new option to the ObjectPointer that allows the a custom GameObject to be provided as the source of the pointer event.
  > 
  > Previously, this source was always the GameObject that the ObjectPointer component was on, but this made it difficult to set rules based around the pointers as the GameObject with the PointerFacade on would not be the source and therefore not make it possible to simply provide the whole pointer prefab in a rule.
  > 
  > This change now sets the top level GameObejct as the ObjectPointer event source so any rule that requires to know about a pointer can simply use the top level pointer prefab GameObject.

## [1.2.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.12...v1.2.0) (2020-04-14)

#### Features

* **Extraction:** update Extractors to use new Zinna generic types ([5a18489](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/5a1848924ddf18f6a93033a9788944e48077f606))
  > Zinnia version 1.15.0 has new generic Extractor types that offer a consistent Extractor API.
  > 
  > The ObjectPointer extractors have been updated so they extend these new generic types so they offer a consistent API.

### [1.1.12](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.11...v1.1.12) (2020-04-11)

#### Bug Fixes

* **Configurator:** ensure custom raycast rules are set up on enable ([93f3550](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/93f35506a86bca0374a68ccda0f8d5955f3b53e1))
  > The Raycast Rules option on the Facade was not being set up in the Configurator when the script became enabled so the actual custom rules were not being copied down to the lower elements that require the rule.

### [1.1.11](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.10...v1.1.11) (2020-04-03)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([171914c](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/171914c218a45841fc0af4e3e8518188b3f2e84c))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.7 to 1.0.8. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.7...v1.0.8)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>
* **deps:** bump io.extendreality.zinnia.unity from 1.14.0 to 1.14.1 ([8df8bb6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/8df8bb69d72076c6298b24d8ed85403fb2cc84fb))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.14.0 to 1.14.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.14.0...v1.14.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.9...v1.1.10) (2020-03-05)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([57b0b37](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/57b0b37c42f18065cf14257544b1c4d7e8a8658e))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.6 to 1.0.7. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.6...v1.0.7)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.9](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.8...v1.1.9) (2020-03-05)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.12.0 to 1.14.0 ([8950b99](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/8950b9928966284b607a70bc18c265423734ca45))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.12.0 to 1.14.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.12.0...v1.14.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.7...v1.1.8) (2020-02-24)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([760b161](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/760b161804b1bac11ea910f9a7c391d6e6544d16))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.5 to 1.0.6. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.5...v1.0.6)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.7](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.6...v1.1.7) (2020-02-24)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.11.0 to 1.12.0 ([ec276ca](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/ec276ca83c25b74c9aafec42bc5e89c84ab9c6a0))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.11.0 to 1.12.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.11.0...v1.12.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.5...v1.1.6) (2020-01-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([1e437d8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/1e437d89e896c2806c49bd149e23444bbfb97406))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.4 to 1.0.5. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.4...v1.0.5)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>
* **deps:** bump io.extendreality.zinnia.unity from 1.9.0 to 1.11.0 ([cf9c5cb](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/cf9c5cb847e1fe09f4353c0f4fe085a1db52b44b))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.9.0 to 1.11.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.9.0...v1.11.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.4...v1.1.5) (2019-12-17)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([bec8e79](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/bec8e79564253eedd9a4118eafe9baff1247112b))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.0.1 to 1.0.2. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.0.1...v1.0.2)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.3...v1.1.4) (2019-12-12)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.utilities.shaders.unity ([e22679a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/e22679af4e0f1400ec08543ca61a550b35ccb3fb))
  > Bumps [io.extendreality.tilia.utilities.shaders.unity](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity) from 1.0.0 to 1.0.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Utilities.Shaders.Unity/compare/v1.0.0...v1.0.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.2...v1.1.3) (2019-12-12)

#### Bug Fixes

* **Runtime:** add missing FodyWeavers.xml file ([399384a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/399384a94a1c83c4b13eacb14712a80c217f7eed))
  > There was no FodyWeavers.xml file so when the package was included in another project it would not load in the Malimbe components and therefore the prefabs would be broken.

### [1.1.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.1...v1.1.2) (2019-12-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([3607856](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/360785693985342f8f40d911064ab9a5667b8dce))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.3 to 1.0.4. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.3...v1.0.4)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.1.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.1.0...v1.1.1) (2019-12-02)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.8.1 to 1.9.0 ([5f83447](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/5f83447308eff74213a71d991d8ede9aed8271a1))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.8.1 to 1.9.0. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.8.1...v1.9.0)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

## [1.1.0](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.6...v1.1.0) (2019-11-29)

#### Features

* **Facade:** expose caster physics cast on facade ([da85d02](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/da85d02b659ecee9b725e10a05a6be93be132157))
  > The internal caster contains a PhysicsCast property that allows the rules of the raycast to be changed. This property is now exposed on the Facade to make it easier to discover and change.

### [1.0.6](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.5...v1.0.6) (2019-11-27)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([74c1512](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/74c15128fbc48a8b592b35c5ac6b02262cf6135c))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.1 to 1.0.3. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.1...v1.0.3)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.0.5](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.4...v1.0.5) (2019-11-27)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.zinnia.unity from 1.8.0 to 1.8.1 ([455c63a](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/455c63af3fa6a65bf7d981f29979aa26c42b4807))
  > Bumps [io.extendreality.zinnia.unity](https://github.com/ExtendRealityLtd/Zinnia.Unity) from 1.8.0 to 1.8.1. - [Release notes](https://github.com/ExtendRealityLtd/Zinnia.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Zinnia.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Zinnia.Unity/compare/v1.8.0...v1.8.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.0.4](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.3...v1.0.4) (2019-11-25)

#### Bug Fixes

* **HowToGuides:** add missing guide for curved pointer ([7d6fc73](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/7d6fc73424423b0c1bc018f25a9fbd4eda325d58))
  > The curved pointer was missing documentation this has now been added.

### [1.0.3](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.2...v1.0.3) (2019-11-25)

#### Bug Fixes

* **HowToGuides:** add missing straight pointer usage guide ([75eb240](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/75eb240920fc76518120d8115089ab7fa597a38f))
  > The Straight Pointer had no user guide to show how to add it to a scene. A new user guide has been added to rectify this issue.

### [1.0.2](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.1...v1.0.2) (2019-11-22)

#### Miscellaneous Chores

* **deps:** bump io.extendreality.tilia.mutators.objectfollower.unity ([1b8bb10](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/1b8bb10276d957d8a3febe3fc4594d6ff532a2ac))
  > Bumps [io.extendreality.tilia.mutators.objectfollower.unity](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity) from 1.0.0 to 1.0.1. - [Release notes](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/releases) - [Changelog](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/blob/master/CHANGELOG.md) - [Commits](https://github.com/ExtendRealityLtd/Tilia.Mutators.ObjectFollower.Unity/compare/v1.0.0...v1.0.1)
  > 
  > Signed-off-by: dependabot-preview[bot] <support@dependabot.com>

### [1.0.1](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/compare/v1.0.0...v1.0.1) (2019-11-22)

#### Bug Fixes

* **Materials:** apply correct material properties ([44750ff](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/44750ffa34fc3a906334af6980096934da15f675))
  > The materials were changed but Unity doesn't seem to save out the properties until Unity is closed.
* **package.json:** provide correct keywords for package ([f195563](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/f19556348ec69587b643cced88acf7e9741944e2))
  > The keywords in the package.json were not appropriate for the pacakge so these have now been updated.

## 1.0.0 (2019-11-22)

#### Features

* **structure:** create initial prefab and user guides ([47eedb8](https://github.com/ExtendRealityLtd/Tilia.Indicators.ObjectPointers.Unity/commit/47eedb8c4903112d4ab9dd0a5fbed29a66e90de0))
  > The structure of the repository has been created with all the required files for the package, the prefab and the installation guide.
